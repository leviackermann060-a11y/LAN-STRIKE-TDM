using UnityEngine;
using UnityEngine.EventSystems;

public class LookDragArea : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public Vector2 Delta { get; private set; }
    private Vector2 previous;
    private bool dragging;

    public void OnPointerDown(PointerEventData e)
    {
        previous = e.position;
        Delta = Vector2.zero;
        dragging = true;
    }

    public void OnDrag(PointerEventData e)
    {
        if (!dragging) return;
        Delta += e.position - previous;
        previous = e.position;
    }

    public void OnPointerUp(PointerEventData e)
    {
        dragging = false;
    }

    public Vector2 ConsumeDelta()
    {
        Vector2 result = Delta;
        Delta = Vector2.zero;
        return result;
    }
}
