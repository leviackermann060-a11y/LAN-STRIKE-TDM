using UnityEngine;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;

public class LanGameBootstrap : MonoBehaviour
{
    [Header("Network")]
    [SerializeField] private NetworkManager networkManager;
    [SerializeField] private UnityTransport transport;
    [SerializeField] private ushort port = 7777;

    [Header("Join")]
    [SerializeField] private string hostAddress = "192.168.1.10";

    private void Awake()
    {
        if (networkManager == null) networkManager = NetworkManager.Singleton;
        if (transport == null && networkManager != null)
            transport = networkManager.GetComponent<UnityTransport>();
    }

    public void SetHostAddress(string address) => hostAddress = address;

    public void StartHost()
    {
        if (!Ready()) return;
        transport.SetConnectionData("127.0.0.1", port, "0.0.0.0");
        if (!networkManager.StartHost())
            Debug.LogError("Could not start LAN host.");
    }

    public void StartClient()
    {
        if (!Ready()) return;
        if (string.IsNullOrWhiteSpace(hostAddress))
        {
            Debug.LogWarning("Enter the host PC/phone's local IPv4 address.");
            return;
        }

        transport.SetConnectionData(hostAddress.Trim(), port);
        if (!networkManager.StartClient())
            Debug.LogError("Could not start LAN client.");
    }

    public void Shutdown()
    {
        if (networkManager != null && networkManager.IsListening)
            networkManager.Shutdown();
    }

    private bool Ready()
    {
        if (networkManager == null || transport == null)
        {
            Debug.LogError("Assign NetworkManager and UnityTransport in the Inspector.");
            return false;
        }
        if (networkManager.IsListening)
        {
            Debug.LogWarning("Network is already running.");
            return false;
        }
        return true;
    }
}
