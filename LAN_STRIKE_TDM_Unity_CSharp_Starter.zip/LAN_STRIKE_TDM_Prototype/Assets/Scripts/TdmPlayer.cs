using UnityEngine;
using Unity.Netcode;
using Unity.Collections;

[RequireComponent(typeof(CharacterController))]
public class TdmPlayer : NetworkBehaviour
{
    [Header("Scene references")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private AudioListener audioListener;
    [SerializeField] private Transform muzzle;
    [SerializeField] private VirtualJoystick moveJoystick;
    [SerializeField] private LookDragArea lookArea;
    [SerializeField] private HoldButton fireButton;
    [SerializeField] private HoldButton sprintButton;
    [SerializeField] private HoldButton jumpButton;

    [Header("Movement")]
    [SerializeField] private float walkSpeed = 5f;
    [SerializeField] private float sprintSpeed = 7.5f;
    [SerializeField] private float jumpHeight = 1.25f;
    [SerializeField] private float gravity = -22f;
    [SerializeField] private float mouseSensitivity = 2f;
    [SerializeField] private float touchSensitivity = 0.12f;
    [SerializeField] private float gyroSensitivity = 1.5f;

    [Header("Weapon")]
    [SerializeField] private float fireRate = 0.095f;
    [SerializeField] private float weaponDamage = 25f;
    [SerializeField] private float weaponRange = 180f;
    [SerializeField] private LayerMask hitMask = ~0;

    public NetworkVariable<int> Team = new NetworkVariable<int>(0);
    public NetworkVariable<int> Kills = new NetworkVariable<int>(0);
    public NetworkVariable<int> Deaths = new NetworkVariable<int>(0);
    public NetworkVariable<int> Health = new NetworkVariable<int>(100);

    private CharacterController character;
    private float verticalVelocity;
    private float pitch;
    private float nextShot;
    private bool gyroEnabled;
    private bool wasGyroEnabled;

    public override void OnNetworkSpawn()
    {
        character = GetComponent<CharacterController>();

        if (IsServer)
            Team.Value = (int)(OwnerClientId % 2);

        if (playerCamera != null) playerCamera.gameObject.SetActive(IsOwner);
        if (audioListener != null) audioListener.enabled = IsOwner;

        if (!IsOwner) return;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        if (SystemInfo.supportsGyroscope)
        {
            Input.gyro.enabled = true;
            gyroEnabled = false; // Enable with the in-game gyro toggle.
        }
    }

    private void Update()
    {
        if (!IsOwner || !IsSpawned) return;
        HandleLook();
        HandleMovement();
        HandleWeapon();
    }

    public void ToggleGyroscope()
    {
        gyroEnabled = !gyroEnabled && SystemInfo.supportsGyroscope;
        if (SystemInfo.supportsGyroscope) Input.gyro.enabled = gyroEnabled;
    }

    private void HandleLook()
    {
        float yaw = 0f;
        float lookPitch = 0f;

        if (Application.isMobilePlatform)
        {
            if (lookArea != null)
            {
                Vector2 d = lookArea.ConsumeDelta();
                yaw += d.x * touchSensitivity;
                lookPitch -= d.y * touchSensitivity;
            }

            if (gyroEnabled)
            {
                Vector3 rate = Input.gyro.rotationRateUnbiased;
                yaw += rate.y * gyroSensitivity * Mathf.Rad2Deg * Time.deltaTime;
                lookPitch += rate.x * gyroSensitivity * Mathf.Rad2Deg * Time.deltaTime;
            }
        }
        else
        {
            yaw = Input.GetAxis("Mouse X") * mouseSensitivity;
            lookPitch = -Input.GetAxis("Mouse Y") * mouseSensitivity;
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            if (Input.GetMouseButtonDown(0))
            {
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
        }

        transform.Rotate(Vector3.up * yaw);
        pitch = Mathf.Clamp(pitch + lookPitch, -85f, 85f);
        if (playerCamera != null)
            playerCamera.transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
    }

    private void HandleMovement()
    {
        float x, z;
        bool sprint, jump;

        if (Application.isMobilePlatform)
        {
            Vector2 move = moveJoystick != null ? moveJoystick.Value : Vector2.zero;
            x = move.x;
            z = move.y;
            sprint = sprintButton != null && sprintButton.IsHeld;
            jump = jumpButton != null && jumpButton.IsHeld;
        }
        else
        {
            x = Input.GetAxisRaw("Horizontal");
            z = Input.GetAxisRaw("Vertical");
            sprint = Input.GetKey(KeyCode.LeftShift);
            jump = Input.GetButtonDown("Jump");
        }

        Vector3 moveDirection = (transform.right * x + transform.forward * z).normalized;
        float speed = sprint ? sprintSpeed : walkSpeed;
        character.Move(moveDirection * speed * Time.deltaTime);

        if (character.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
        if (jump && character.isGrounded)
            verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);

        verticalVelocity += gravity * Time.deltaTime;
        character.Move(Vector3.up * verticalVelocity * Time.deltaTime);
    }

    private void HandleWeapon()
    {
        bool fire = Application.isMobilePlatform
            ? (fireButton != null && fireButton.IsHeld)
            : Input.GetMouseButton(0);

        if (!fire || Time.time < nextShot || playerCamera == null) return;
        nextShot = Time.time + fireRate;

        Vector3 origin = playerCamera.transform.position;
        Vector3 direction = playerCamera.transform.forward;
        FireServerRpc(origin, direction);
    }

    [Rpc(SendTo.Server)]
    private void FireServerRpc(Vector3 origin, Vector3 direction)
    {
        if (Health.Value <= 0) return;

        if (Physics.Raycast(origin, direction.normalized, out RaycastHit hit,
            weaponRange, hitMask, QueryTriggerInteraction.Ignore))
        {
            TdmPlayer victim = hit.collider.GetComponentInParent<TdmPlayer>();
            if (victim != null && victim != this && victim.Team.Value != Team.Value)
                victim.TakeDamageServer((int)weaponDamage, this);
        }
    }

    private void TakeDamageServer(int amount, TdmPlayer attacker)
    {
        if (!IsServer || Health.Value <= 0) return;

        Health.Value = Mathf.Max(0, Health.Value - amount);
        if (Health.Value == 0)
        {
            attacker.Kills.Value++;
            Deaths.Value++;
            Invoke(nameof(RespawnServer), 3f);
        }
    }

    private void RespawnServer()
    {
        if (!IsServer || !IsSpawned) return;

        Vector3 spawn = Team.Value == 0
            ? new Vector3(-8f, 1.1f, 0f)
            : new Vector3(8f, 1.1f, 0f);

        if (character != null) character.enabled = false;
        transform.SetPositionAndRotation(spawn, Quaternion.identity);
        if (character != null) character.enabled = true;
        Health.Value = 100;
    }

    public override void OnNetworkDespawn()
    {
        if (IsOwner)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }
}
