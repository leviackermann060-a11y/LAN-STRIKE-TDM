# LAN STRIKE – TDM (Unity C# starter)

A cross-platform Unity starter for a first-person LAN Team Deathmatch prototype.
This is source code, not a finished APK/EXE. You must open it in Unity, create the scene,
assign references, and build for Android and Windows.

## Requirements

- Unity 6 (or a recent Unity 2022.3 LTS version)
- Universal Render Pipeline (URP)
- Packages via Window > Package Manager:
  - Netcode for GameObjects
  - Unity Transport
- Android Build Support (SDK, NDK, OpenJDK) for Android builds

## 1. Create the project

1. Create a new **3D (URP)** Unity project named `LanStrikeTDM`.
2. Install **Netcode for GameObjects** and **Unity Transport** in Package Manager.
3. Copy `Assets/Scripts` from this starter into your Unity project's `Assets` folder.

## 2. Create the network manager

1. Create an empty GameObject named `NetworkManager`.
2. Add `NetworkManager` and `UnityTransport` components.
3. In NetworkManager, set **Player Prefab** to your player prefab.
4. Add the player prefab to **Network Prefabs** if your NGO version requires it.
5. Add a scene object with `LanGameBootstrap`; assign the NetworkManager and UnityTransport.

## 3. Create the player prefab

1. Create a Capsule, rename it `Player`.
2. Add `CharacterController` and `NetworkObject`.
3. Add `NetworkTransform` and configure it for **owner-authoritative** movement
   (the owner moves their character; other clients receive replicated transforms).
4. Add `TdmPlayer`.
5. Add a Camera as a child at local position `(0, 0.65, 0)`.
6. Assign the Camera and its AudioListener in `TdmPlayer`.
7. Drag the player object into the Project window to make a prefab.
8. Assign that prefab to NetworkManager's Player Prefab field.

**Important:** For a production shooter, replace owner-authoritative movement with server
validation, lag compensation, anti-cheat checks, and server-side hit validation. This starter
is for trusted local Wi-Fi play and learning.

## 4. Build a basic test map

- Add a Plane at `(0, 0, 0)` and scale it to `(8, 1, 8)`.
- Add walls, crates, containers and cover using cubes.
- Put two team spawn areas around `(-8, 1, 0)` and `(8, 1, 0)`.
- Keep the player prefab's capsule collider/controller dimensions sensible.
- Add lighting, skybox, terrain, PBR materials and baked lighting for the realistic look.

The prototype's respawn points are currently fixed at x = -8 and x = +8.
Make sure the map has enough room around those positions.

## 5. Add the LAN menu

Create a Canvas with:
- Host button -> `LanGameBootstrap.StartHost()`
- Join button -> `LanGameBootstrap.StartClient()`
- An input field for the host's local IPv4 address -> call `SetHostAddress(string)`

All devices must be on the same Wi-Fi/LAN. The host starts the match. Other devices enter
the host device's local IPv4 address (for example `192.168.1.20`) and press Join.
Allow UDP port **7777** through the host PC firewall. Some Wi-Fi routers enable client
isolation; disable it or devices will not see each other.

## 6. Mobile controls

Create UI elements under the Canvas:
- A left-side joystick background with a child handle; add `VirtualJoystick` to background.
- A right-side transparent look panel; add `LookDragArea`.
- Fire, sprint and jump UI buttons; add `HoldButton` to each.
- Assign those components to the matching fields on `TdmPlayer` prefab.

Add an EventSystem and ensure the Canvas has a GraphicRaycaster. The look panel's Image
should have **Raycast Target** enabled. Put the joystick and buttons above the look panel
in the Canvas hierarchy so they receive touch input first.

For Android, set Player Settings > Active Input Handling to **Both** or **Input Manager
(Old)** because this prototype reads the legacy keyboard/mouse axes on PC.

The gyro toggle can be connected to a UI button calling `TdmPlayer.ToggleGyroscope()`.
Gyro support depends on the phone sensor and needs per-device sensitivity calibration.

## 7. Current prototype scope and limitations

Included:
- LAN host/client start
- Two teams assigned by client ID parity
- Local first-person camera
- Keyboard/mouse and mobile virtual controls
- Walk, sprint, jump, touch look and optional gyro aiming
- Repeating hitscan rifle, 25 damage, 100 health
- Team filtering, kill/death counters and 3-second respawn

Not yet included:
- Finished art assets, realistic weapon models/animations, skins, audio, recoil visuals,
  reload animation, scoreboard UI, match timer, kill feed, matchmaking or internet servers.
- A polished mobile HUD and full anti-cheat/network security.

## 8. Build

### Windows
File > Build Profiles > Windows > Build. Use the host's LAN IPv4 address for clients.

### Android
Install Android Build Support. Switch Platform to Android, set package identifier,
choose ARM64, set orientation to Landscape, then Build. Install the APK on each phone.

## Troubleshooting

- If Host/Join does nothing, check Console and confirm NetworkManager/UnityTransport refs.
- If clients cannot connect, check same Wi-Fi, host IP, UDP 7777, firewall and router client isolation.
- If remote players do not move smoothly, check NetworkTransform authority and interpolation.
- If controls do not respond, check EventSystem, GraphicRaycaster and UI raycast targets.
